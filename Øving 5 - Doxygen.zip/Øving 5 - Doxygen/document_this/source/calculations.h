#ifndef CALCULATIONS_H
#define CALCUATIONS_H
#include "system.h"

// Document this
double calculate_P_parameter(System * current_system);

// Document this
double calculate_I_parameter(System * current_system);

// Document this
double calculate_D_parameter(System * current_system);

#endif
